from __future__ import annotations
from dataclasses import dataclass
import math
import os
from smartgrid_mas.audit.actions import AuditAction
from smartgrid_mas.agents.state import AgentState


@dataclass
class RewardWeights:
    """v19: Target metrics from paper: 42.5% cost, 93.8% coverage, 87.9% risk mitigation"""
    lambda_attack: float = float(os.environ.get("SMARTGRID_RW_ATTACK", 2.0))
    lambda_audit: float = float(os.environ.get("SMARTGRID_RW_AUDIT", 0.50))
    lambda_stability: float = float(os.environ.get("SMARTGRID_RW_STABILITY", 0.05))
    bonus_react: float = float(os.environ.get("SMARTGRID_RW_BONUS", 1.0))
    lambda_risk_excess: float = float(os.environ.get("SMARTGRID_RW_RISK_EXCESS", 0.30))
    min_freq_high_risk: int = int(os.environ.get("SMARTGRID_RW_MIN_FREQ_HR", 1))
    lambda_low_coverage: float = float(os.environ.get("SMARTGRID_RW_LOW_COVERAGE", 0.50))
    lambda_budget_barrier: float = float(os.environ.get("SMARTGRID_RW_BUDGET_BARRIER", 5.0))


def compute_reward(
    st: AgentState,
    action: AuditAction,
    risk_threshold: float,
    mean_baseline_delta: float,
    attacks_stopped: int = 0,
    audit_cost: float = 0.0,
    over_budget_excess: float = 0.0,
    weights: RewardWeights | None = None,
    cost_scale: float | None = None,
    prev_risk: float | None = None,
    budget_utilization: float | None = None,
    num_agents: int | None = None,
    system_c_failure: float = 0.0,
) -> float:
    """
    v19: PAPER-ALIGNED REWARD FUNCTION
    
    TARGET METRICS:
    - Cost efficiency: 42.5% (budget ~$16,560 for N=100)
    - Audit coverage: 93.8% (audit strategically, not everyone)
    - Anomaly detection: 98.4% (we have 99.5% ✓)
    - Risk mitigation: 87.9% POSITIVE (not -29%!)
    - False positive rate: 3.2% (allow some false positives)
    
    OBJECTIVE: Maximize risk mitigation while spending ~$16.5k per cycle
    """
    if weights is None:
        weights = RewardWeights()

    # Safety cliff threshold
    CRITICAL_THRESHOLD = 5.0
    
    # =============== PENALTY COMPONENTS ===============
    
    # 1. SAFETY CLIFF: If grid is crashing, fail immediately
    if mean_baseline_delta > CRITICAL_THRESHOLD:
        return -500.0 - (mean_baseline_delta * 10.0)
    
    # 2. BUDGET BALANCE: Target $16,560 for N=100 (165.6 audits @ $100 each)
    # Don't penalize small deviations - we want to learn the right budget
    ideal_budget_per_100_agents = 165.6
    if num_agents and num_agents != 100:
        ideal_budget = ideal_budget_per_100_agents * (num_agents / 100.0)
    else:
        ideal_budget = ideal_budget_per_100_agents
    
    # Only penalize LARGE deviations (>30% off target)
    budget_ratio = audit_cost / max(1.0, ideal_budget)
    budget_penalty = 0.0
    if budget_ratio > 1.3 or budget_ratio < 0.7:  # >30% off target
        budget_penalty = abs(budget_ratio - 1.0) * 3.0  # Scale with severity
    
    # 3. DETECTION QUALITY: Paper FP/FN balance
    # Estimate FP = auditing low-risk agents (cost waste)
    # Estimate FN = not auditing high-risk agents (security failure)
    estimated_fp = 0.0
    estimated_fn = 0.0
    
    if st.risk_score < 0.3 and action == AuditAction.INC:
        estimated_fp = 1.0  # Likely auditing normal agent
    elif st.risk_score > 0.7 and action == AuditAction.DEC:
        estimated_fn = 1.0  # Likely missing attack
    
    # Paper formula: R = -α₁×FP - α₂×FN (where α₂ > α₁)
    alpha_1 = 0.5   # FP cost (audit waste)
    alpha_2 = 2.0   # FN cost (miss attack) - MUST be > α₁
    detection_penalty = (alpha_1 * estimated_fp) + (alpha_2 * estimated_fn)
    
    # =============== BONUS COMPONENTS ===============
    
    # 1. PRIMARY OBJECTIVE: Risk mitigation (87.9% target!)
    # Reward RL for keeping mean_baseline_delta low (physical stability = real risk reduction)
    risk_mitigation_reward = 0.0
    if mean_baseline_delta < 0.3:
        risk_mitigation_reward = 10.0  # Grid is very stable
    elif mean_baseline_delta < 0.5:
        risk_mitigation_reward = 8.0   # Grid is stable
    elif mean_baseline_delta < 1.0:
        risk_mitigation_reward = 4.0   # Grid is manageable
    elif mean_baseline_delta < 2.0:
        risk_mitigation_reward = 1.0   # Grid is acceptable
    else:
        risk_mitigation_reward = -2.0  # Grid is degrading
    
    # 2. DETECTION BONUS: Catch actual threats (True Positives)
    detection_bonus = 0.0
    if attacks_stopped > 0:
        detection_bonus = 5.0 * float(attacks_stopped)
    
    # 3. STRATEGIC AUDITING: Allow 3.2% FPR (not perfect precision)
    # Don't over-penalize false positives - some auditing "waste" is okay
    # This prevents RL from being overly conservative
    strategic_bonus = 0.0
    if st.anomaly_flag == 1 and st.audit_frequency > 0:
        strategic_bonus = 1.0  # Modest bonus for finding something (even if FP rate is 3.2%)
    
    # =============== TOTAL REWARD ===============
    # FORMULA: risk_mitigation_reward + detection_bonus + strategic_bonus - budget_penalty - detection_penalty
    #
    # Priority 1: Risk mitigation (87.9% target) - weights up to 10.0
    # Priority 2: Detection quality - weights ~5.0 each
    # Priority 3: Budget balance - penalize only large deviations
    #
    # This ensures RL learns: RISK > DETECTION > COST
    
    total_reward = (
        risk_mitigation_reward         # Primary: stability (up to 10.0)
        + detection_bonus              # Secondary: catch threats (+5.0 each)
        + strategic_bonus              # Tertiary: find something (+1.0)
        - budget_penalty               # Penalize only large budget deviations
        - detection_penalty            # Penalize FP/FN misbalance
    )
    
    return float(total_reward)
