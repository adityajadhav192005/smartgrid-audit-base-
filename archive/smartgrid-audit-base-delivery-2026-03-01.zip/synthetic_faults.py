from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import numpy as np


class FaultType(Enum):
    NONE = 0
    VOLTAGE_SAG = 1
    OVERCURRENT = 2
    FREQ_DEV = 3


@dataclass
class PhysIndexMap:
    v_idx: int = 0
    i_idx: int = 1
    f_idx: int = 2


@dataclass
class FaultConfig:
    sag_pct: float = 0.3
    surge_pct: float = 0.2
    overcurrent_pct: float = 0.5
    freq_delta: float = 1.0


def apply_fault(x: np.ndarray, ftype: FaultType, idx: PhysIndexMap, cfg: FaultConfig) -> np.ndarray:
    x = x.astype(float).copy()
    if ftype == FaultType.VOLTAGE_SAG and idx.v_idx < x.shape[0]:
        x[idx.v_idx] = x[idx.v_idx] * (1.0 - cfg.sag_pct)
    elif ftype == FaultType.OVERCURRENT and idx.i_idx < x.shape[0]:
        x[idx.i_idx] = x[idx.i_idx] * (1.0 + cfg.overcurrent_pct)
    elif ftype == FaultType.FREQ_DEV and idx.f_idx < x.shape[0]:
        x[idx.f_idx] = x[idx.f_idx] + cfg.freq_delta
    return x
