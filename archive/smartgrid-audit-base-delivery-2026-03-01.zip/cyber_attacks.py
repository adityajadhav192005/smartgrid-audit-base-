from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Tuple
import numpy as np


class AttackType(Enum):
    NONE = 0
    FDI = 1
    DOS = 2
    MITM = 3


@dataclass
class AttackConfig:
    fdi_bias: float = 2.0
    fdi_drift: float = 0.05
    dos_latency_increase: float = 5.0
    dos_integrity_drop: float = 0.5
    mitm_noise_std: float = 1.0


class AttackInjector:
    def __init__(self, cfg: AttackConfig | None = None):
        self.cfg = cfg or AttackConfig()

    def apply_fdi(self, x: np.ndarray, t: int) -> np.ndarray:
        bias = self.cfg.fdi_bias
        drift = self.cfg.fdi_drift * float(t)
        return (x + bias + drift).astype(float)

    def apply_dos(self, y: np.ndarray) -> np.ndarray:
        y = y.astype(float).copy()
        y[0] = y[0] + self.cfg.dos_latency_increase
        y[1] = float(min(1.0, y[1] + 0.2))
        y[2] = float(max(0.0, y[2] - self.cfg.dos_integrity_drop))
        if y.shape[0] >= 4:
            y[3] = float(max(0.0, y[3] * 0.95))
        return y

    def apply_mitm(self, x: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        nx = np.random.normal(0.0, self.cfg.mitm_noise_std, size=x.shape)
        ny = np.zeros_like(y, dtype=float)
        if y.shape[0] >= 1:
            ny[0] = np.random.normal(0.0, 0.5)
        if y.shape[0] >= 2:
            ny[1] = np.random.normal(0.0, 0.02)
        y2 = (y + ny).astype(float).copy()
        if y2.shape[0] >= 3:
            y2[2] = float(max(0.0, y2[2] - 0.1))
        return (x + nx).astype(float), y2
