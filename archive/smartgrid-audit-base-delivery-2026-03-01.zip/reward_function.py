from __future__ import annotations
from dataclasses import dataclass
import os

from smartgrid_mas.audit.actions import AuditAction
from smartgrid_mas.agents.state import AgentState


@dataclass
class RewardWeights:
    """Paper-aligned reward weights (pinned reference)."""

    # Eq.-style objective weights
    lambda_attack: float = float(os.environ.get("SMARTGRID_RW_ATTACK", 2.0))
    lambda_audit: float = float(os.environ.get("SMARTGRID_RW_AUDIT", 0.5))
    lambda_stability: float = float(os.environ.get("SMARTGRID_RW_STABILITY", 0.1))
    bonus_react: float = float(os.environ.get("SMARTGRID_RW_BONUS", 1.0))
    lambda_risk_excess: float = float(os.environ.get("SMARTGRID_RW_RISK_EXCESS", 0.30))
    min_freq_high_risk: int = int(os.environ.get("SMARTGRID_RW_MIN_FREQ_HR", 1))
    lambda_low_coverage: float = float(os.environ.get("SMARTGRID_RW_LOW_COVERAGE", 0.50))
    lambda_budget_barrier: float = float(os.environ.get("SMARTGRID_RW_BUDGET_BARRIER", 5.0))


def compute_reward(
    st: AgentState,
    action: AuditAction,
    risk_threshold: float,
    mean_baseline_delta: float,
    attacks_stopped: int = 0,
    audit_cost: float = 0.0,
    over_budget_excess: float = 0.0,
    weights: RewardWeights | None = None,
    cost_scale: float | None = None,
    prev_risk: float | None = None,
    budget_utilization: float | None = None,
    num_agents: int | None = None,
    system_c_failure: float = 0.0,
) -> float:
    """
    Pinned-paper aligned reward:

    1) Cost objective (Eq. 2 inspired):
       C = C_a * f + C_f * (R / f)
       where here `audit_cost` carries C_a*f and we model R/f per-agent.

    2) Detection penalty (paper text):
       R_det = -(alpha_1 * FP + alpha_2 * FN), with alpha_2 > alpha_1.

    3) Physical safety guardrail:
       hard penalty beyond critical baseline deviation.
    """
    if weights is None:
        weights = RewardWeights()

    critical_threshold = 5.0
    if mean_baseline_delta > critical_threshold:
        return -500.0 - (mean_baseline_delta * 10.0)

    # ---- Detection terms (FP/FN) ----
    estimated_fp = 0.0
    estimated_fn = 0.0
    if st.risk_score < 0.3 and action == AuditAction.INC:
        estimated_fp = 1.0
    elif st.risk_score > 0.7 and action == AuditAction.DEC:
        estimated_fn = 1.0

    alpha_1 = weights.lambda_audit   # FP weight
    alpha_2 = 2.0                    # FN weight (heavier)
    det_penalty = (alpha_1 * estimated_fp) + (alpha_2 * estimated_fn)

    # ---- Cost objective terms ----
    # audit_cost is C_a*f for this agent contribution.
    c_audit = max(0.0, float(audit_cost))

    # R/f term: protect high-risk agents from low frequency.
    f_eff = max(1.0, float(st.audit_frequency))
    r_over_f = float(st.risk_score) / f_eff
    c_failure = weights.lambda_attack * r_over_f

    # Optional system-level shared failure term (from scheduler)
    if num_agents and num_agents > 0 and system_c_failure > 0.0:
        c_failure += 0.5 * (float(system_c_failure) / float(num_agents))

    # Stability pressure (cross-layer objective)
    stability_penalty = weights.lambda_stability * max(0.0, float(mean_baseline_delta))

    # Reactive bonus when high-risk and we increase audits
    react_bonus = 0.0
    if st.risk_score >= risk_threshold and action == AuditAction.INC:
        react_bonus = weights.bonus_react

    # Small bonus for verified blocked attacks
    detect_bonus = 0.25 * float(attacks_stopped) if attacks_stopped > 0 else 0.0

    total_cost = c_audit + c_failure + stability_penalty
    reward = -total_cost - det_penalty + react_bonus + detect_bonus
    return float(reward)
